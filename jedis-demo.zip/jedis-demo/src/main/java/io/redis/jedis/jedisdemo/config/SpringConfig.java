package io.redis.jedis.jedisdemo.config;

import org.apache.commons.pool2.impl.GenericObjectPoolConfig;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisPassword;
import org.springframework.data.redis.connection.RedisStandaloneConfiguration;
import org.springframework.data.redis.connection.jedis.JedisClientConfiguration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.ListOperations;
import org.springframework.data.redis.core.SetOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.JdkSerializationRedisSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.util.StringUtils;

import io.redis.jedis.jedisdemo.model.Programmer;

@Configuration
public class SpringConfig {

	@Value("${spring.redis.host}")
	private String redisDBHost;
	
	@Value("${spring.redis.port}")
	private int redisDBPort;
	
	@Value("${spring.redis.password}")
	private String redisDBPassword;
	
	@Value("${spring.redis.jedis.pool.max-active}")
	private int redisPoolMaxActive;
	
	@Value("${spring.redis.jedis.pool.max-idle}")
	private int redisPoolMaxIdle;
	
	@Value("${spring.redis.jedis.pool.min-idle}")
	private int redisPoolMinIdle;
	
	//Step 1 Creating Jedis Client Configuration
	@Bean
	public JedisClientConfiguration getJedisClientConfiguration() {
		JedisClientConfiguration.JedisPoolingClientConfigurationBuilder JedisPoolingClientConfigurationBuilder = (JedisClientConfiguration.JedisPoolingClientConfigurationBuilder) JedisClientConfiguration
				.builder();
		GenericObjectPoolConfig GenericObjectPoolConfig = new GenericObjectPoolConfig();
		GenericObjectPoolConfig.setMaxTotal(redisPoolMaxActive);
		GenericObjectPoolConfig.setMaxIdle(redisPoolMaxIdle);
		GenericObjectPoolConfig.setMinIdle(redisPoolMinIdle);
		return JedisPoolingClientConfigurationBuilder.poolConfig(GenericObjectPoolConfig).build();
		// https://commons.apache.org/proper/commons-pool/apidocs/org/apache/commons/pool2/impl/GenericObjectPool.html
	}
	
	//Step 2 creating Jedis connection factory(54)
	@Bean
	public JedisConnectionFactory getJedisConnectionFactory() {
		RedisStandaloneConfiguration redisStandaloneConfiguration = new RedisStandaloneConfiguration();
		redisStandaloneConfiguration.setHostName(redisDBHost);
		if (!StringUtils.isEmpty(redisDBPassword)) {
			redisStandaloneConfiguration.setPassword(RedisPassword.of(redisDBPassword));
		}
		redisStandaloneConfiguration.setPort(redisDBPort);
		return new JedisConnectionFactory(redisStandaloneConfiguration, getJedisClientConfiguration());
	}
	
	// Step 3 Creating Redis Template
	@Bean
	public RedisTemplate redisTemplate() {
		RedisTemplate<String, Object> redisTemplate = new RedisTemplate<String, Object>();
		redisTemplate.setConnectionFactory(getJedisConnectionFactory());
		redisTemplate.setKeySerializer(new StringRedisSerializer());
//   	 redisTemplate.setKeySerializer(new StringRedisSerializer());
 //  	 redisTemplate.setValueSerializer(new JdkSerializationRedisSerializer());
//        redisTemplate.setHashKeySerializer(new StringRedisSerializer());
//        redisTemplate.setHashValueSerializer(new StringRedisSerializer()));
		return redisTemplate;
	}

	@Bean
	@Qualifier("listOperations")
	public ListOperations<String, Programmer> listOperations(RedisTemplate<String, Programmer> redisTemplate) {
		return redisTemplate.opsForList();
	}
	
	@Bean
	@Qualifier("setOperations")
	public SetOperations<String, Programmer> SetOperations(RedisTemplate<String, Programmer> redisTemplate) {
		return redisTemplate.opsForSet();
	}
	
	 @Bean
	public HashOperations<String, Integer, Programmer> hashOps(RedisTemplate<String, Object>  redisTemplate) {
	        return redisTemplate.opsForHash();
	    }
}
